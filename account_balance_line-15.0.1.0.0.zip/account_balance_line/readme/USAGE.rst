#. If you're an accounting adviser, enable developer mode and go to
   Accounting > Adviser > Journal items.
#. Or open an account or a partner, and click on Action > Journal items.
#. You will see a column named "Balance" with the balance of the line.
