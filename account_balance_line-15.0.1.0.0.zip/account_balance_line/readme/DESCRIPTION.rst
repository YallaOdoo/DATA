This module adds a balance total for lines in move line view.
